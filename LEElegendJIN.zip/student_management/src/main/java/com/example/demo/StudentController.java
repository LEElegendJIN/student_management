package com.example.demo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.http.HttpResponse;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class StudentController {

	@Autowired
	StudentRepository rep;
	
	@GetMapping("/student_add")
	public String student_add(
			@ModelAttribute("student") StudentEntity student
			) {
		
		return "student_add";
	}
	
	@PostMapping("/student_upload")
	public String student_upload(
			@ModelAttribute("student") StudentEntity student,
			@RequestParam("student_photo") MultipartFile file,
			RedirectAttributes redirectAttributes
			) {
		
		if(!file.isEmpty()) {
			
		try {
			InputStream is = file.getInputStream();
			student.setPhoto(is.readAllBytes());
			student.setContentType(file.getContentType());
			
			rep.save(student);
			/*
			 * redirectAttributes.addFlashAttribute("message", "You successfully uploaded "
			 * + file.getOriginalFilename() + "!");
			 */
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
		return "student_add";
	}
	
	@GetMapping("/student_getimage/{studentNo}")
	public void GetImage(
			@PathVariable("studentNo") String studentNo,
			HttpServletResponse response) {
		
		Optional<StudentEntity> student = rep.findById(studentNo);
		
		OutputStream os = null;
		StudentEntity s = new StudentEntity();
		
		if(student.isPresent()) {
			
			s = student.get();
			response.setContentType(s.getContentType());
	        
			try {
				os = response.getOutputStream();
				os.write(s.getPhoto());
		        os.flush();
		        os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
}
