package com.example.demo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class StudyController {

	// @Value(${favorite.fruits})
	// private List<String> fruitList;

	@GetMapping("sum_javascript")
	public String sum_js() {

		return "study/sum_javascript";
	}

	@GetMapping("sum_input")
	public String sum_input(Model model) {
		// now 메소드가 static 이기 때문에 new 를 사용하지 않는다
		LocalDateTime dateTime = LocalDateTime.now();

		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		String today = dateTime.format(df);
		model.addAttribute("today", today);

		return "study/sum_input";
	}

	@PostMapping("sum_add")
	public String sum_add(Model model, // DI
			@RequestParam("first_value") int firstValue, @RequestParam("second_value") int secondValue) {
		// 형 변환
		// int nValue1 = Integer.parseInt(firstValue);
		// int nValue2 = Integer.parseInt(secondValue);

		int sum = firstValue + secondValue;
		model.addAttribute("sum", sum);
		LocalDateTime dateTime = LocalDateTime.now();

		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		String today = dateTime.format(df);
		model.addAttribute("today", today);
		model.addAttribute("firstValue", firstValue);
		model.addAttribute("secondValue", secondValue);

		return "study/sum_result";
	}

	@GetMapping("bmi_input")
	public String bmi_input() {

		return "study/bmi_input";
	}

	@PostMapping("bmi_calc")
	public String bmi_calc(@RequestParam("height") int height, @RequestParam("weight") int weight, Model model) {

		// BMI = (kg/m^2)
		double dHeight = (double) height / 100.0;
		// double dBMI = (double)weight / (dHeight * dHeight);
		double dBMI = (double) weight / Math.pow(dHeight, 2); // 기독성 simple

		// 소수점 2째리에서 반올림하여 소수 1째리까지 표시하는 로직
		double dBMI1 = Math.round(dBMI * 10.0) / 10.0;

		String strResult = "";

		if (dBMI < 18.5) {
			strResult = "저체중";
		} else if (dBMI < 23) {
			strResult = "정상";
		} else if (dBMI < 25) {
			strResult = "과체중";
		} else {
			strResult = "비만";
		}

		model.addAttribute("height", height);
		model.addAttribute("weight", weight);
		// model.addAttribute("bmi", dBMI);
		model.addAttribute("bmi", dBMI1);
		model.addAttribute("result", strResult);

		return "study/bmi_result";
	}

	@GetMapping("bmi_input_usingclass")
	public String bmi_input_usingclass(@ModelAttribute("bmiCalc") BmiCalc bmiCalc) {

		return "study/bmi_input_usingclass";
	}

	@PostMapping("bmi_calc_usingclass")
	public String bmi_calc_usingclass(@ModelAttribute("bmiCalc") BmiCalc bmiCalc, Model model) {
		int height = bmiCalc.getHeight();
		int weight = bmiCalc.getWeight();

		bmiCalc.bmiCalc();
		double dBMI = bmiCalc.getBmi();
		String result = bmiCalc.getResult();

		model.addAttribute("bmi", dBMI);
		model.addAttribute("result", result);

		return "study/bmi_result_usingclass";
	}

	@GetMapping("shape_area")
	public String shape_area() {
		return "study/shape_area";
	}

	@PostMapping("shape_calc")
	public String shape_calc(@RequestParam("submit_calc") String submitValue, @RequestParam("garo") int garo,
			@RequestParam("sero") int sero, @RequestParam("base") int base, @RequestParam("height") int height) {
		System.out.println(garo);

		if (submitValue.equals("사각형 넓이 계산")) {
			int rect_sum = garo + sero;
		} else if (submitValue.equals("삼각형 넓이 계산")) {
			double tri_sum = (double) base * (double) height / 2.0;
		}

		return "study/shape_result";
	}

	@GetMapping("select_option")
	public String select_option(Model model) {

		List<String> fruitList = Arrays.asList("사과", "배", "포도", "복숭아", "망고");

//		List<String> fruitList = new ArrayList<>(Arrays.asList(fruitArray));

		model.addAttribute("fruitList", fruitList);
		model.addAttribute("selected", "복숭아");

		return "study/select_option";
	}

	@GetMapping("gugudan")
	public String gugudan(Model model) {

		// 3단 구구단 작성 == model
		int nDan = 333;
		List<String> gugudanList = new ArrayList<>();

		for (int i = 1; i <= 9; i++) {
			String gugu = String.format("%d × %d = %2d", nDan, i, nDan * i);
			gugudanList.add(gugu);
		}

		model.addAttribute("gugudanList", gugudanList);

		return "study/gugudan";
	}

	@GetMapping("gugudan_input")
	public String gugudan_input() {

		return "study/gugudan_input";
	}

	@PostMapping("gugudan_show")
	public String gugudan_show(@RequestParam("gugudan") int gugudan, Model model) {

		// int gugudan1 = gugudan;
		// List<String> gugudanList = new ArrayList<>();

		String totalGugudan = "";
		for (int i = 1; i <= 9; i++) {
			totalGugudan += String.format("%d × %d = %2d", gugudan, i, gugudan * i) + "<br>";
		}

		model.addAttribute("gugudan", totalGugudan);
		return "study/gugudan_result";
	}

	@GetMapping("gugudan_reverse_input")
	public String gugudan_reverse_input() {

		return "study/gugudan_reverse_input";
	}

	@PostMapping("gugudan_reverse_dis")
	public String gugudan_reverse_dis(@RequestParam("gugudan") int gugudan, Model model) {

		// 구구단 역순 표시
		String totalGugudan = "";
		for (int i = 9; i >= 1; i--) {
			totalGugudan += String.format("%d × %d = %2d", gugudan, i, gugudan * i) + "<br>";
		}

		model.addAttribute("gugudan", totalGugudan);
		return "study/gugudan_reverse_dis";
	}

	@GetMapping("one_to_ten_sum")
	public String one_to_ten_sum(Model model) {

		int nStart = 1;
		int nStop = 10;
		int sum = 0;

		for (int i = nStart; i <= nStop; i++) {
			sum += i;
		}

		String message = String.format("1~10의 합은 '%d'입니다.", sum);
		model.addAttribute("message", message);

		return "study/one_to_ten_sum";
	}

	@GetMapping("get_my_is")
	public String get_my_is() {

		return "study/get_my_is";
	}

	@PostMapping("get_my_result")
	public String get_my_result(@RequestParam("birth_year") int birthYear, Model model) {
		List<String> myList = Arrays.asList("자", "축", "인", "묘", "진", "사", "오", "미", "신", "유", "술", "해");
		int myNumber = (birthYear + 8) % 12;
		String myIs = myList.get(myNumber);

		model.addAttribute("myIs", myIs);

		LocalDateTime date = LocalDateTime.now();
		int currentYear = date.getYear();

		int age = currentYear - birthYear - 1;
		model.addAttribute("age", age);

		model.addAttribute("myList", myList);

		return "study/get_my_result";
	}

	@GetMapping("mynotepad") // 메소드는 같지만 인자가 다르다. 다중정의 메소드
	public String mynotepad() {

		return "study/mynotepad";
	}

	@PostMapping("mynotepad") // 메소드는 같지만 인자가 다르다. 다중정의 메소드
	public String mynotepad(Model model, @RequestParam("mytext") String myText, @RequestParam("command") String command)
			throws IOException {

		String fileName = "notepad_test.txt"; // "C:/임시/notepad_test.txt" C드라이브에 임시 폴더에 생성 임시 폴더 없으면 오류남
												// "C:/notepad_test.txt" C드라이브에 생성
												// "notepad_test.txt" 프로젝트 폴더에 생성

		if (command.equals("열기")) {
			FileReader file = new FileReader(fileName);
			BufferedReader br = new BufferedReader(file);
			String myReadText = "";
			while (true) {
				String s = br.readLine();
				if (s == null) {
					break;
				}
				myReadText += s + "\n";

			}
			br.close();
			model.addAttribute("myReadText", myReadText);

		} else if (command.equals("저장")) {
			FileWriter file = new FileWriter(fileName);
			PrintWriter pw = new PrintWriter(new BufferedWriter(file));

			pw.println(myText);

			pw.close();

		}

		return "study/mynotepad";
	}

	@GetMapping("img_mouseover")
	public String img_mouseover() {
		return "study/img_mouseover";
	}

	@GetMapping("photo_all_dis")
	public String photo_all_dis(Model model) {
		List<String> photoList = Arrays.asList("1-1", "2-1", "3-1", "4-1", "5-1", "6-1", "7-1", "8-1", "9-1", "10-1",
				"11-1", "12-1", "1-2", "2-2", "3-2", "4-2", "5-2", "6-2", "7-2", "8-2", "9-2", "10-2", "11-2", "12-2");

		model.addAttribute("photoList", photoList);

		return "study/photo_all_dis";

	}

	@GetMapping("photo_random_result")
	public String photo_random_result(Model model) {

		// List<String> Arrays.asList 많이 쓰니까 곡 기억해두자
		List<String> photoList = new ArrayList<String>(
				Arrays.asList("1-1", "2-1", "3-1", "4-1", "5-1", "6-1", "7-1", "8-1", "9-1", "10-1", "11-1", "12-1",
						"1-2", "2-2", "3-2", "4-2", "5-2", "6-2", "7-2", "8-2", "9-2", "10-2", "11-2", "12-2"));

		// 선생님이 짠 코드

		int nCountsToExtract = 4;
		Collections.shuffle(photoList);
		Random random = new Random();
		List<Photo> photoClassList = new ArrayList<>();

		for (int i = 0; i < nCountsToExtract; i++) {
			int nEXtractedIndex = random.nextInt(photoList.size());
			String strExtractedCaption = photoList.get(nEXtractedIndex);

			Photo photo = new Photo();
			photo.setCaption(strExtractedCaption);
			photoList.remove(nEXtractedIndex);

			String[] strSplitedCaption = strExtractedCaption.split("-");
			int nExtractedNumber = Integer.parseInt(strSplitedCaption[0]);
			photo.setNumber(nExtractedNumber);

			photoClassList.add(photo);
		}

		model.addAttribute("photoClassList", photoClassList);

		// 판정
		int nMyNumberSum = photoClassList.get(0).getNumber() + photoClassList.get(1).getNumber();

		int nComputerNumberSum = photoClassList.get(2).getNumber() + photoClassList.get(3).getNumber();
		int nMyRemainder = nMyNumberSum % 10;
		int nComputerRemainder = nComputerNumberSum % 10;

		String strResult = "";
		if (nMyRemainder > nComputerRemainder) {
			strResult = "WIN";
		} else if (nMyRemainder == nComputerRemainder) {
			strResult = "DRAW";
		} else {
			strResult = "LOSE";
		}
		model.addAttribute("strResult", strResult);

		return "study/photo_random_result";
	}

	@GetMapping("radio_dis")
	public String radio_dis() {

		return "study/radio_dis";
	}

	@PostMapping("radio_result")
	public String radio_result(@RequestParam("favorite_fruit") String favoriteFruit, Model model) {

		model.addAttribute("favoriteFruit", favoriteFruit);
		return "study/radio_result";
	}

	@GetMapping("select_auto_change")
	public String select_auto_change(Model model) {
		List<String> favoriteFruitList = Arrays.asList("사과", "배", "포도", "망고", "바나나");
		model.addAttribute("favoriteFruitList", favoriteFruitList);
		model.addAttribute("selectedFruit", "바나나");
		return "study/select_auto_change";
	}

	@PostMapping("select_auto_change_process")
	public String select_auto_change_process(@RequestParam("favorite_fruit") String favoriteFruit, Model model) {
		model.addAttribute("favoriteFruit", favoriteFruit);
		return "study/select_auto_change_result";
	}

	@GetMapping("block_inline")
	public String block_inline(Model model) {

		return "study/block_inline";
	}

	@GetMapping("ceil_roundup_floor")
	public String ceil_roundup_floor() {

		return "study/ceil_roundup_floor";
	}

	@GetMapping("ceil_roundup_floor_result")
	public String ceil_roundup_floor_result(
			@RequestParam("input_number") double dInputNumber,
			@RequestParam("float_digit") int nFloatDigit, 
			@RequestParam("radio_option") String strRadioOption,
			Model model
			
			) {
		
		double lResult = 0;
		double dBojo = Math.pow(10, nFloatDigit-1);
		

		if (strRadioOption.equals("올림")) {
			
			lResult = Math.ceil(dInputNumber * dBojo) / dBojo;
			
		} 
		else if (strRadioOption.equals("반올림")) {
			
			lResult = Math.round(dInputNumber * dBojo) / dBojo;
		} 
		else{
			lResult = Math.floor(dInputNumber * dBojo) / dBojo;
		}

		model.addAttribute("lResult", lResult);
		return "study/ceil_roundup_floor_result";
	}

	@GetMapping("try_lotto")
	public String try_lotto() {
		
		return "study/try_lotto";
	}
	/*
	 * @PostMapping("try_lotto") public String try_lotto( Model model ) {
	 * 
	 * return "study/try_lotto"; }
	 */
	
	
}


































