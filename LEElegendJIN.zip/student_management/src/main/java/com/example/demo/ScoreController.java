package com.example.demo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ScoreController {
	@Autowired // Dependency Injection 의존성 주입
	ScoreRepository rep;

	@Value("${Paging.recordCountsPerPage}")
	private Integer[] nRecordsArray;

	@Value("${Paging.defaultRecordCounts}")
	private int nDefaultRecordCounts;

	@GetMapping("/")
	public String index() {

		return "index";
	}

	@GetMapping("/add")
	public String add(@ModelAttribute("score") ScoreEntity score) {

		return "add";
	}

	@PostMapping("/add")
	public String add(@ModelAttribute("score") @Validated ScoreEntity score, BindingResult result) {

		if (result.hasErrors()) {
			return "add";
		} else {
			if (rep.existsById(score.getStudentNo()) == true) {
				// 학사번호가 DB에 존재하면 "DB에 이미 등록되어 있습니다." 메시지 표시
				FieldError fieldError = new FieldError("score", "studentNo", "DB에 이미 등록되어 있습니다.");
				result.addError(fieldError);
				return "add";
			} else {
				Date date = new Date();
				String pattern = "yyyy-MM-dd HH:mm:ss";
				SimpleDateFormat df = new SimpleDateFormat(pattern);
				String strCreatedDate = df.format(date);
				score.setCreatedDate(strCreatedDate);

				ScoreEntity s = rep.save(score);
				if (s.getStudentNo() != null) {
					// 정상 등록
				}
			}

			return "redirect:/alldis";
		}
	}

	@GetMapping("/alldis")
	public String alldis(Model model, @RequestParam(name = "gubun", defaultValue = "first") String gubun,
			@RequestParam(name = "currentPage", defaultValue = "0") int currentPage,
			@RequestParam(name = "totalPages", defaultValue = "0") int totalPages) {
		long lTotalCounts = rep.count(); // select count(*) from score;
		model.addAttribute("TotalCounts", lTotalCounts);

		Paging paging = new Paging();
		paging.setSelectedRecordNumber(nDefaultRecordCounts);
		paging.setGubun(gubun);
		paging.setCurrentPage(currentPage);
		paging.setTotalPageCounts(totalPages);

		int nCurrentPage = paging.getCurrentPage();
		int nTotalPageCounts = paging.getTotalPageCounts();
		String strGubun = paging.getGubun();

		switch (strGubun) {
		case "first":
			paging.setCurrentPage(0);
			break;
		case "previous":
			if (nCurrentPage > 0) {
				paging.setCurrentPage(--nCurrentPage);
			}
			break;
		case "next":
			if (currentPage < paging.getTotalPageCounts() - 1) {
				paging.setCurrentPage(++nCurrentPage);
			}
			break;
		case "last":
			paging.setCurrentPage(nTotalPageCounts - 1);
			break;
		}

		Pageable pageable = PageRequest.of(nCurrentPage, 10);
		Page<ScoreEntity> pageList = rep.findAll(pageable);
		List<ScoreEntity> scoreList = pageList.getContent();

		List<ScoreEntity> myScoreList = new ArrayList<>();

		for (int i = 0; i < scoreList.size(); i++) {
			ScoreEntity score = new ScoreEntity();
			score = scoreList.get(i);

			int guk = score.getGuk();
			int math = score.getMath();
			int sahee = score.getSahee();

			double average = (double) (guk + math + sahee) / 3.0;
			average = Double.parseDouble(String.format("%.1f", average));
			score.setAverage(average);
			String strDate = score.getCreatedDate();

			if (strDate != null) {
				String[] strArray = strDate.split(" ");
				score.setCreatedDate(strArray[0].trim()); // yyyy-MM-dd 표시
			}

			myScoreList.add(score);
		}

		model.addAttribute("scoreList", myScoreList);

		return "alldis";
	}

	/*
	 * @GetMapping("/edit") public String edit() {
	 * 
	 * return "edit"; }
	 */

	/*
	 * @GetMapping("/edit1") public String edit1( Model model,
	 * 
	 * @RequestParam("studentNo") String studentNo) { System.out.println(studentNo);
	 * 
	 * 
	 * Optional<ScoreEntity> score = rep.findById(studentNo); if(score.isPresent())
	 * { ScoreEntity s = score.get(); model.addAttribute("beforeScore", s); }
	 * 
	 * return "edit"; }
	 */

	@GetMapping("/edit")
	public String edit(Model model, @RequestParam("studentNo") String studentNo,
			@ModelAttribute("afterScore") ScoreEntity afterScore
	) {

		Optional<ScoreEntity> beforeScore = rep.findById(studentNo);
		if (beforeScore.isPresent()) {
			ScoreEntity s = beforeScore.get();
			model.addAttribute("beforeScore", s);
		}

		return "edit";
	}
	
	@PostMapping("/update")
	public String update(
			@ModelAttribute("afterScore") ScoreEntity afterScore
			) {
		
		return "update_result";
	}

	@GetMapping("/score_all_dis")
	public String score_all_dis(
			Model model, 
			@RequestParam(name = "gubun", defaultValue = "first") String gubun,
			@RequestParam(name = "currentPage", defaultValue = "0") int currentPage,
			@RequestParam(name = "totalPages", defaultValue = "2") int totalPages
			) {
		System.out.println(gubun);

		if (gubun.equals("first")) {
			currentPage = 0;
		} else if (gubun.equals("previous")) {
			if (currentPage > 0) {
				currentPage--;
			}
		} else if (gubun.equals("next")) {
			if (currentPage < totalPages - 1) {
				currentPage++;
			}
		} else if (gubun.equals("last")) {
			currentPage = totalPages - 1;
		}

		Pageable pageable = PageRequest.of(currentPage, 15);
		;
		currentPage = pageable.getPageNumber();
		model.addAttribute("currentPage", currentPage);

		Page<ScoreEntity> pageList = rep.findAll(pageable);

		totalPages = pageList.getTotalPages();
		model.addAttribute("totalPages", totalPages);

		List<ScoreEntity> scoreList = pageList.getContent();
		List<ScoreEntity> myScoreList = new ArrayList<>();

		for (int i = 0; i < scoreList.size(); i++) {
			ScoreEntity score = new ScoreEntity();
			score = scoreList.get(i);

			int guk = score.getGuk();
			int math = score.getMath();
			int sahee = score.getSahee();

			double average = (double) (guk + math + sahee) / 3.0;
			average = Double.parseDouble(String.format("%.1f", average));
			score.setAverage(average);

			myScoreList.add(score);

		}

		model.addAttribute("scoreList", myScoreList);

		// 조인, 분할
		// List<Integer> recordsList = Arrays.asList(10, 15, 20, 25, 30);
		// List<Integer> recordsList = Arrays.asList(nRecordsArray);
		List<Integer> recordsList = new ArrayList<>(Arrays.asList(nRecordsArray));

		model.addAttribute("recordsList", recordsList);
		model.addAttribute("recordsPerPage", 30);

		return "score_all_dis";
	}
}
