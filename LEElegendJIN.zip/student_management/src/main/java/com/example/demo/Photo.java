package com.example.demo;

public class Photo {
	private String caption;
	private int number;

	public Photo() {
	}

	public Photo(String caption, int number) {
		super();
		this.caption = caption;
		this.number = number;
	}

	public String getCaption() {
		return caption;
	}
	public void setCaption(String caption) {
		this.caption = caption;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
}
