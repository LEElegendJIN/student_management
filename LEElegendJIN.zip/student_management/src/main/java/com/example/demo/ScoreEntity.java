package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name= "score")
public class ScoreEntity {

	@Id   // 기본 키
	@Column(name="student_no", length = 8)
	@NotBlank(message="필수 입력입니다.")
	@Pattern(regexp="[0-9]{5}", message="학사번호는 5자리입니다.")
	private String studentNo;  // camel 방식
	
	@Min(value=0, message="0점 이상이어야 합니다.")
	@Max(value=100, message="100점 이하여야 합니다.")
	@Column(name="guk")
	private int guk;
			
	@Min(value=0, message="0점 이상이어야 합니다.")
	@Max(value=100, message="100점 이하여야 합니다.")
	@Column(name="math")
	private int math;
	
	@Min(value=0, message="0점 이상이어야 합니다.")
	@Max(value=100, message="100점 이하여야 합니다.")
	@Column(name="sahee")
	private int sahee;
	
	@Transient  // 테이블에 생성하지 않는다
	private double average;
	
	@Column(name="created_date", length = 19)
	private String createdDate;
			
	public ScoreEntity() {
	}
	
	public ScoreEntity(String studentNo, int guk, int math, int sahee) {
		this.studentNo  = studentNo;
		this.guk = guk;
		this.math = math;
		this.sahee = sahee;
	}
	
	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}
	
	public String getStudentNo() {
		return studentNo;
	}
	
	public void setGuk(int guk) {
		this.guk = guk;
	}
	
	public int getGuk() {
		return guk;
	}
	
	public void setMath(int math) {
		this.math = math;
	}
	
	public int getMath() {
		return math;
	}
	
	public void setSahee(int sahee) {
		this.sahee = sahee;
	}
	
	public int getSahee() {
		return sahee;
	}
	
	public void setAverage(double average) {
		this.average = average;
	}
	
	public double getAverage() {
		return average;
	}
	
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getCreatedDate() {
		return createdDate;
	}

}
