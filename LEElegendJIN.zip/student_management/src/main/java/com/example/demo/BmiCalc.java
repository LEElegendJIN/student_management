package com.example.demo;

public class BmiCalc {

	private int height; // cm
	
	private int weight; 
	
	private double bmi;
	
	private String result;

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public double getBmi() {
		return bmi;
	}

	public void setBmi(double bmi) {
		this.bmi = bmi;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
	
	public void bmiCalc() {
		double dHeight = (double)height / 100.0;
		// double dBMI = (double)weight / (dHeight * dHeight);
		double dBMI = (double)weight / Math.pow(dHeight, 2);  // 기독성 simple
		
		// 소수점 2째리에서 	반올림하여 소수 1째리까지 표시하는 로직
		double dBMI1 = Math.round(dBMI * 10.0) / 10.0;
		this.bmi = dBMI1;
		
		String strResult = "";
		
		if(dBMI < 18.5) {
			strResult = "저체중";
		}
		else if(dBMI < 23) {
			strResult = "정상";
		}
		else if(dBMI < 25) {
			strResult = "과체중";
		}
		else {
			strResult = "비만";
		}
		
		this.result = strResult;
	}

}
