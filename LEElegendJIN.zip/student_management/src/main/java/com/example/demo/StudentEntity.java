package com.example.demo;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name= "student")
public class StudentEntity {

	public StudentEntity() {
		super();
	}

	public String getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	@Id   // 기본 키
	@Column(name="student_no", length = 8)
	@NotBlank(message="필수 입력입니다.")
	@Pattern(regexp="[0-9]{5}", message="학사번호는 5자리입니다.")
	private String studentNo;  // camel 방식
	
	@NotBlank(message="필수 입력입니다.")
	@Column(name="name", length = 10)
	private String name;
	
	@Lob()
	@Column(name="photo", length=100000)
	private byte[] photo;
			
	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	@Column(name="content_type", length=20)
	private String contentType;
	
	

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public byte[] getPhoto() {
		return photo;
	}

	@Pattern(regexp = "[0-9]{3}-[0-9]{4}-[0-9]{4}", message="정확한 전호번호를 입력하십시오.")
	@Column(name="tel")
	private String tel;
	
	@Column(name="created_date", length = 19)
	private String createdDate;

}
