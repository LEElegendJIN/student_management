package com.example.demo;

public class Paging {
	private String strGubun; 
	private int nCurrentPage;
	private int nTotalPageCounts;
	public Integer[] nRecordNumberArray;
	private int nSelectedRecordNumber;

	public Paging() {
	}
	
	public Paging(String strGubun, int nCurrentPage,
			int nTotalPageCounts, int nSelectedRecordNumber) {
		this.strGubun = strGubun;
		this.nCurrentPage = nCurrentPage;
		this.nTotalPageCounts = nTotalPageCounts;
		this.nSelectedRecordNumber = nSelectedRecordNumber;
	}
	
	public void setGubun(String strGubun) {
		this.strGubun = strGubun;
	}
	
	public String getGubun() {
		return strGubun;
	}
	
	public void setCurrentPage(int nCurrentPage) {
		this.nCurrentPage = nCurrentPage;
	}
	
	public int getCurrentPage() {
		return nCurrentPage;
	}
	
	public void setTotalPageCounts(int nTotalPageCounts) {
		this.nTotalPageCounts = nTotalPageCounts;
	}
	
	public int getTotalPageCounts() {
		return nTotalPageCounts;
	}
	
	public void setSelectedRecordNumber(int nSelectedRecordNumber) {
		this.nSelectedRecordNumber = nSelectedRecordNumber;
	}
	
	public int getSelectedRecordNumber() {
		return nSelectedRecordNumber;
	}
}
